"""
Code for makept (serializing and subprocesses) strategy.
"""
