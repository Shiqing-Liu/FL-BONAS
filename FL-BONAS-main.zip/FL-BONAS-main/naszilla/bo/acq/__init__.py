"""
Code for acquisition strategies.
"""
