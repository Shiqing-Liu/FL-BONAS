"""
Code for domain classes.
"""
