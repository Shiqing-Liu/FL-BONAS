"""
Miscellaneous utilities.
"""
