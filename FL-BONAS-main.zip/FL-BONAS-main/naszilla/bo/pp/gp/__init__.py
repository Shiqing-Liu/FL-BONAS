"""
Code for Gaussian process (GP) utilities and functions.
"""
