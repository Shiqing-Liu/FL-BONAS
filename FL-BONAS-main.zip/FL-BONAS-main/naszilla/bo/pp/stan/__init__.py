"""
Code for defining and compiling models in Stan.
"""
