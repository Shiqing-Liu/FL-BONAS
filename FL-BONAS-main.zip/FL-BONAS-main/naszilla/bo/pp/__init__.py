"""
Code for defining and running probabilistic programs.
"""
