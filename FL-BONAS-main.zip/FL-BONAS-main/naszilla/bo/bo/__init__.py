"""
Code for Bayesian optimization.
"""
