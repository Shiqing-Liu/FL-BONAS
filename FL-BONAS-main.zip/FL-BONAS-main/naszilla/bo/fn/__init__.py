"""
Code for synthetic functions to query (perform experiment on).
"""
