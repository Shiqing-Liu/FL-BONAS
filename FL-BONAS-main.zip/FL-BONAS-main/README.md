# FL-BONAS
Federated Bayesian Optimization for Privacy-preserving Neural Architecture Search
